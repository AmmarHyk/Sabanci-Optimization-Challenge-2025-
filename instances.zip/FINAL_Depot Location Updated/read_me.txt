Format of the input files:

first line: two integers seperated by spaces:
N(number of communities) M(number of healthcenters)

second line: represents the coordinates of the depot(node 0) that will be used in the second-stage problem
0	x-coordinate-of-Depot	y-coordinate-of-Depot

other lines: five values seperated by spaces: 
community(node)_index  x-coordinate y-coordinate  C(capacity of a healthcenter if deployed) population_size 